package com.bsit.pboard.adapter;

public interface YearCheckListener {
    void onYearCheck(int type, String status, Object result);
}
