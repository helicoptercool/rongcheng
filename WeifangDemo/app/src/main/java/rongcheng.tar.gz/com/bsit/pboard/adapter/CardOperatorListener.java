package com.bsit.pboard.adapter;

public interface CardOperatorListener {
    void onCardOperate(int type, Object response);
}
