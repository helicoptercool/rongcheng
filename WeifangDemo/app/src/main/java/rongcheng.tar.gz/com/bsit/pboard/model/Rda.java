package com.bsit.pboard.model;

public class Rda {
	private String biVer;
	private String biPath;
	private String bhVer;
	private String bhPath;
	public String getBiVer() {
		return biVer;
	}
	public void setBiVer(String biVer) {
		this.biVer = biVer;
	}
	public String getBiPath() {
		return biPath;
	}
	public void setBiPath(String biPath) {
		this.biPath = biPath;
	}
	public String getBhVer() {
		return bhVer;
	}
	public void setBhVer(String bhVer) {
		this.bhVer = bhVer;
	}
	public String getBhPath() {
		return bhPath;
	}
	public void setBhPath(String bhPath) {
		this.bhPath = bhPath;
	}
}
